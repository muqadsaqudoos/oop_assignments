with open('grades.txt','w') as file:
    file.write("courses\troll_no\tpercent_marks\n")
    file.write("probability\tbssef22a015\t73.6\n")
    
    file.write("oop\tbssef22a015\t90.2\n")
    file.write("dld\tbsdsf22a031\t82.1\n")
    file.write("probability\tbsdsf22a031\t83.1\n")
    file.write("oop\tbsdsf22a036\t78.8\n")
    
  
    file.write("dld\tbsdsf22a036\t85.1\n")
    file.write("probability\tbssef22a014\t93.1\n")
    file.write("oop\tbssef22a014\t53.1\n")

    file.write("dld\tbssef22a015\t53.1\n")
    file.write("probability\tbssef22a015\t53.1\n")

    
    
    
    
